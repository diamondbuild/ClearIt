# Handoff: ClearIt UI Redesign + Design System

## Overview
ClearIt explains confusing real-world things — bills, letters, scam texts, forms, error messages — in plain English, telling the user **what it is, what it means, whether it's safe, and what to do next**. This handoff is a full visual redesign of the existing app plus a reusable design system. The chosen direction is **"Lens"**: a bold, camera-first, broad-consumer rework built around the metaphor *"point at anything confusing and get a clear answer."*

The redesign covers **9 screens**: Home (capture), Analyze (upload/paste), Loading, Result (the core answer card), History, Settings, and three action tools — Call script, Draft reply, Checklist.

## About the Design Files
The file in this bundle (`ClearIt Redesign.dc.html`) is a **design reference created in HTML** — a prototype showing the intended look, layout, and behavior. **It is not production code to copy directly.** Your task is to **recreate these designs inside the existing ClearIt codebase** (Next.js App Router + React + TypeScript + Tailwind CSS) using its established patterns and component structure. Re-style the existing components rather than introducing the HTML wholesale.

The HTML is one self-contained "board" that lays out all screens side-by-side as phone frames, followed by a design-system section. Read it as a styling/spec source, screen by screen.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, radii, shadows, and copy are all specified below with exact values. Recreate the UI as closely as possible using the codebase's existing libraries (Tailwind, and `lucide-react` for icons — all icons in the design are Lucide-style rounded line icons). Match measurements precisely.

---

## Target Codebase Map
Apply the system to these existing files (from `github.com/diamondbuild/ClearIt`, the `clearit/` app):

| File | What to change |
|---|---|
| `app/globals.css` | Add the color/spacing/font CSS variables (token list below). Set app background to `#FBF8F4` (light) / `#141019` (dark). |
| `tailwind.config.ts` (or `.js`) | Extend `colors`, `fontFamily` (`display`, `sans`), `borderRadius`, `boxShadow` with the tokens below. |
| `app/layout.tsx` | Load fonts **Bricolage Grotesque** (display) + **Hanken Grotesk** (body) via `next/font/google`. Wire dark mode (class strategy). |
| `app/page.tsx` | Home screen → camera-first capture layout (see Home spec). |
| `components/Header.tsx` | Logo lockup: gradient rounded-square scan icon + "ClearIt" in Bricolage 800. |
| `components/BottomNav.tsx` | 4 tabs: Home, Scan, History, Settings (Lucide icons + 10px labels). |
| `components/ResultCard.tsx` | Rebuild as the hero answer card + sectioned content (see Result spec). |
| `components/UrgencyBadge.tsx` | Map to the 5-level urgency token set below. |
| `components/SafetyNotice.tsx` | High-contrast scam/emergency alert (see Safety notice component). |
| `lib/types.ts` | Urgency enum values map 1:1 to the urgency levels below. |

> Replace all **emoji section headers** (📄 💡 ✅) with the Lucide line-icon tiles described under Components.

---

## Design Tokens

### Color — Brand
| Token | Hex | Use |
|---|---|---|
| `violet-950` | `#2A1466` | deepest |
| `violet-700` | `#5A2FC9` | text-on-light accent |
| **`violet-600` (primary)** | **`#6C3CE0`** | primary brand |
| `violet-400` | `#9C7CF0` | dark-mode accent text, eyebrows |
| `violet-200` | `#C9B6F2` | borders, dashed |
| `violet-50` | `#F0E9FC` | tinted surfaces |
| `coral-700` | `#C2541C` | high-priority text |
| `coral-600` | `#E0581E` | high-priority dot |
| **`coral-500` (accent)** | **`#FF6A45`** | accent / gradient end |
| `coral-400` | `#FF8366` | dark-mode accent |
| `coral-200` | `#FFB39E` | — |
| `coral-50` | `#FFE9E2` | — |
| **Brand gradient** | `linear-gradient(135deg, #6C3CE0, #FF6A45)` | primary CTAs, FAB, logo tile, progress |

### Color — Neutrals (light)
`#FFFFFF` surface · `#FBF8F4` **app background** · `#F1EADD` hairline/divider · `#E6DECF` border · `#C4BBCB` disabled · `#857C92` muted text · `#3D3849` body text · `#1B1622` **ink (headings)**

### Color — Surfaces (dark)
`#0B0710` deepest · `#141019` **app background** · `#1E1826` card · `#271F31` raised · `#322940` border/track · accent text `#9C7CF0` / `#FF8366`

### Color — Urgency (5 levels)
| Level | Text | Dot/Icon | Background |
|---|---|---|---|
| Low priority | `#0B7D58` | `#0E9F6E` | `#E7F6EF` |
| Medium | `#946012` | `#B7791F` | `#FCF3E3` |
| High priority | `#C2541C` | `#E0581E` | `#FDEEE4` |
| Possible scam | `#C42620` | `#E0322E` | `#FCE9E7` |
| Emergency | `#FFFFFF` | `#FFFFFF` | `#B91C1C` (solid) |

*Principle: red is reserved for real risk (scam/emergency). Never alarmist.*

### Typography
- **Display:** `Bricolage Grotesque`, weights 700/800. Headlines only.
- **Body/UI:** `Hanken Grotesk`, weights 400–700.

| Style | Family / Weight | Size | Line-height | Letter-spacing |
|---|---|---|---|---|
| Display XL | Bricolage 800 | 54px | 1.0 | -0.025em |
| Display | Bricolage 800 | 30–40px | 1.0–1.1 | -0.02em |
| Title | Bricolage 700–800 | 22–26px | 1.1 | -0.01em |
| Body L | Hanken 500 | 16px | 1.6 | — |
| Body | Hanken 500 | 14–14.5px | 1.5–1.55 | — |
| Label/Caption | Hanken 700 | 11.5–12px | — | 0.08–0.12em, UPPERCASE |

### Spacing — 4pt scale
`4, 8, 12, 16, 24, 32, 48` (px). Screen gutters: 16–24px. Card padding: 14–18px.

### Radius
`10` (icon tiles) · `13–16` (buttons, small cards) · `18–20` (cards) · `26` (hero card) · `46` (phone frame) · `9999` (pills, FAB, toggles, status dots).

### Shadow / Elevation
| Token | Value |
|---|---|
| sm | `0 1px 2px rgba(26,22,38,.08)` |
| md | `0 6px 20px rgba(26,22,38,.1)` |
| lg | `0 18px 40px rgba(26,22,38,.16)` |
| hero card | `0 10px 30px -12px rgba(26,22,38,.18)` |
| glow (brand) | `0 12px 30px -6px rgba(108,60,224,.6)` |

### Icons
Lucide-style rounded line icons, stroke `2–2.4`, `stroke-linecap/linejoin: round`. Use `lucide-react`. Core set: `Camera`, `ScanLine`/`Focus`, `ShieldCheck`, `ShieldAlert`/`AlertTriangle`, `Clock` (history), `Settings`, `Phone`, `Mail`, `ListChecks`, `Share2`, `Bookmark`, `Search`, `ChevronLeft`, `ChevronRight`, `Image`, `Send`, `Plus`, `Check`.

---

## Screens / Views

> All screens are mobile, ~390px wide. Light screens use `#FBF8F4` bg; dark screens use `#141019` / radial violet gradient. Each has a 9:41 status bar.

### 1. Home — Capture (dark)
- **Purpose:** Entry point. "Point at anything confusing."
- **Layout (top→bottom):** status bar → top bar (logo lockup left, avatar circle right) → centered **viewfinder** (≈192×192, radius 34, animated corner brackets in violet+coral, sweeping scan line, diagonal-hatch fill, `scanpulse` animation) → headline **"What is this?"** (Bricolage 800, 30px, white, centered) + subcopy ("A bill, a meme, a pill, a letter, an error. Point and get a plain answer.", `#B7AECB`) → horizontal scroll **quick-action chips** ("Is this a scam?", "Explain this bill", "This pill"; pill, `rgba(255,255,255,.1)` bg) → **capture controls row** (absolutely positioned, ~106px from bottom): gallery button (50×50 rounded-16), center **shutter FAB** (78px circle, brand gradient, glow shadow, 4px translucent ring, Camera icon), scan/crop button → **bottom nav**.
- **Note:** keep clear vertical separation between chips and the capture row (they previously overlapped — chips sit above, FAB row below).

### 2. Analyze — Upload & paste (light)
- **Purpose:** Provide input when not using live camera.
- **Layout:** back header "Explain something" → headline "Show me what's confusing." → **dropzone** (radius 24, gradient tint `#F3EDFD→#FFF1EC`, 2px dashed `#C9B6F2`): gradient icon tile (Camera), "Take a photo" / "or drop a screenshot here", two buttons **Camera** (dark `#1B1622`) + **Gallery** (white, bordered) → "OR PASTE TEXT" divider → paste field (white card, radius 18, blinking caret) → primary **"Explain it"** button (gradient, full width, radius 18) → privacy line with lock icon: "Private — your photo never leaves your device."

### 3. Loading — Reading it (dark)
- **Purpose:** Processing state.
- **Layout:** centered scanning card (178×224, dark, skeleton text lines) with a sweeping gradient scan band (`sweep` animation) → 3 pulsing dots (violet/violet/coral, `blip` staggered) → "Reading the details…" (Bricolage 800, 23px, white) → "Checking what it is, what it means, and whether it's safe."

### 4. Result — The answer card (light) ★ core screen
- **Purpose:** Deliver the answer + safe next steps. (Demo scenario: a bank-impersonation scam text.)
- **Layout (sticky header + scroll):**
  - **Sticky header:** back button, "Your answer" title, share button (all 38px white tiles, radius 12).
  - **Hero answer card** (white, radius 26, `0 10px 30px -12px` shadow): top 6px gradient bar (`#E0322E→#FF6A45`, color reflects urgency) → category chip (`Bank alert`, violet-50/violet-700) + urgency chip (`Possible scam`, scam tokens, ShieldAlert icon) → headline "This text is pretending to be your bank." (Bricolage 800, 25px) → body explanation (`#5C5568`) → divider → **Confidence meter**: label + 3 segment bars (filled `#6C3CE0`, empty `#E6DECF`) + "High".
  - **Safety notice** (when scam/emergency): `#FCEAE8` bg, 1.5px `#F4B5AE` border, radius 20; red `#E0322E` icon tile (AlertTriangle); bold title "Don't click the link or call the number." + supporting line. (See SafetyNotice component.)
  - **Section cards** (white, radius 20): icon tile + title header, then body. e.g. **"What it means"** (violet tile, lightbulb) and **"What to do next"** (green tile, check) with numbered steps (dark `#1B1622` numbered circles).
  - **Tools grid** (2×2): Call script, Write reply, Checklist, Explain simpler (white, bordered, radius 15, violet Lucide icon + label).
  - **Bottom actions:** Save (white, bordered) + **Scan another** (gradient, flex-grow).

### 5. History — Saved answers (light)
- **Layout:** sticky header with title "History" (Bricolage 800, 27px) + search field → grouped lists ("Today", "Earlier this week") → **history rows** (white, radius 18): colored icon tile (urgency-tinted) + title + "{urgency} · {time}" subtitle + urgency status dot on the right.

### 6. Settings (dark)
- **Layout:** sticky header "Settings" → grouped sections with UPPERCASE labels:
  - **Appearance:** Theme segmented control (Light / **Dark** / Auto; selected = gradient).
  - **Reading:** Text size slider (gradient fill, white thumb) + "Read aloud" toggle.
  - **Privacy:** "Save history on device" toggle (on = gradient) + "Clear all history" row (chevron).
  - Footer: "ClearIt v2.0 · Explains information. Not legal, medical, or financial advice."
- **Toggles:** 46×27 pill track; on = brand gradient, off = `#E6DECF` (light) / `#322940` (dark); 21px white knob.

### 7. Call script (light) — action tool
- **Layout:** back header "Call script" → context row (gradient Phone tile + "Call your bank directly" / "Use the number on the back of your card") → **number card** (`#F0E9FC` bg): "Official fraud line" label + big number "0800 400 100" (Bricolage 800, 25px) → **"Say this"** card: icon header + quoted script with key phrases bolded → green reassurance note ("They'll never ask for your full PIN or password") → **"Call now"** gradient button (Phone icon).

### 8. Draft reply (light) — action tool
- **Layout:** back header "Draft reply" → "To: Your energy provider" field → **Tone** pills (Firm / **Polite** selected / Short; selected = dark) → message card (white, radius 20): "Suggested message" header + edit (pencil) icon + drafted body with bolded values + blinking caret → buttons **Copy** (white, bordered) + **Use this reply** (gradient, Send icon).

### 9. Checklist (light) — action tool
- **Layout:** back header "Your checklist" → **progress card** (brand gradient, radius 20): "Staying safe" + "1 / 4" + white progress bar (25%) → checklist rows (white, radius 16): completed = green filled circle + check + strikethrough muted text; pending = 2px `#D8CFE6` ring + `#1B1622` text → dashed **"Add your own step"** row (violet, Plus icon).

---

## Components (reusable)
- **Button — primary:** gradient bg, white text, Hanken 700, radius 15–18, glow shadow. Icon-left optional.
- **Button — dark:** `#1B1622` bg, white text.
- **Button — secondary:** white, 1px `#E4DACB` border, `#1B1622` text.
- **Button — ghost:** `#F0E9FC` bg, `#5A2FC9` text.
- **Chip:** pill; selected = dark/`#1B1622` white; default = white bordered; tinted = `#F0E9FC`/violet-700.
- **Input / Search:** white, 1px `#E4DACB` border, radius 13–14, muted placeholder, leading icon.
- **Segmented control:** track `#F1EADD` (light), 4px padding, selected segment = dark or gradient, radius 10–13.
- **Toggle:** see Settings.
- **Confidence meter:** 3 segment bars (22×6, radius 9) + Low/Med/High label.
- **Section card:** icon tile (30px, radius 9, tinted) + title (Hanken 700, 15px) + body (`#454051`, 14px, lh 1.6).
- **Safety notice:** `#FCEAE8`/`#F4B5AE`, red icon tile, bold `#A01E19` title + `#B5403A` body. Reserved for scam/emergency.
- **Urgency badge:** pill with leading dot or icon; colors per urgency table.
- **History row / list item:** icon tile + title + meta + trailing status dot.
- **Bottom nav:** 4 items, active = ink/white + filled-ish icon, inactive = muted; 10px bold labels.
- **Phone-frame / status bar** in the HTML are presentation chrome only — **do not** implement these in the app.

## Interactions & Behavior
- **Capture FAB** → opens camera / triggers analyze → Loading → Result.
- **Quick-action chips & Analyze inputs** → Loading → Result.
- **Result tools** (Call script / Draft reply / Checklist / Explain simpler) → push the corresponding tool screen.
- **History row** → reopens its Result.
- **Animations:** `scanpulse` (3.2s viewfinder pulse), `sweep` (2.2–2.6s scan line), `blip` (1.1–1.4s dot/caret), `shimmer`/`spin` available for skeletons/spinners. Easing `ease-in-out`. Keep transitions ~150–250ms.
- **Theme:** Light / Dark / Auto (system) — class-based dark mode.
- **Accessibility:** large tap targets (≥44px; FAB 78px), high text contrast, text-size control in Settings, "Read aloud" option. Respect `prefers-reduced-motion` (disable scan animations).

## State Management
- `theme`: 'light' | 'dark' | 'auto'
- `textSize`, `readAloud`, `saveHistoryOnDevice` (persisted; history stays on device per privacy line)
- `analysisInput`: { type: 'photo' | 'text', payload }
- `analysisStatus`: 'idle' | 'loading' | 'done' | 'error'
- `result`: { category, urgency (low|medium|high|scam|emergency), title, summary, confidence (low|med|high), whatItMeans, steps[], safetyNotice?, tools[] }
- `history`: Result[] grouped by date
- `checklist`: { items: { label, done }[] }

## Assets
- **Fonts:** Bricolage Grotesque + Hanken Grotesk (Google Fonts).
- **Icons:** Lucide (`lucide-react`) — no custom SVGs needed; the logo mark is a `Focus`/`ScanLine`-style icon on a gradient tile.
- No raster images or photography are required by the design (capture uses a live viewfinder treatment).

## Files
- `ClearIt Redesign.dc.html` — the full design board (all 9 screens + design-system reference). Open in a browser; read screen-by-screen for exact styling.

## Screenshots
Per-screen reference images live in `screens/` (numbering matches the Screens section above):

| File | Screen |
|---|---|
| `screens/01-screen.png` | Home — Capture |
| `screens/02-screen.png` | Result — The answer card |
| `screens/03-screen.png` | Analyze — Upload & paste |
| `screens/04-screen.png` | Loading |
| `screens/05-screen.png` | History |
| `screens/06-screen.png` | Settings |
| `screens/07-screen.png` | Call script |
| `screens/08-screen.png` | Draft reply |
| `screens/09-screen.png` | Checklist |
